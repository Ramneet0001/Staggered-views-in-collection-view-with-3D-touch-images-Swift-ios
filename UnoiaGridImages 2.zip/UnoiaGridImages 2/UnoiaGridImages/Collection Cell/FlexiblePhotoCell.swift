//
//  FlexiblePhotoCell.swift
//  UnoiaGridImages
//
//  Created by MAC on 04/10/18.
//  Copyright © 2018 Ramneet. All rights reserved.
//

import UIKit

class FlexiblePhotoCell: UICollectionViewCell {
    
    @IBOutlet fileprivate weak var containerView: UIView!
    @IBOutlet fileprivate weak var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        containerView.layer.cornerRadius = 5
        containerView.layer.masksToBounds = true
    }
    
    var photo: PhotoModel? {
        
        didSet {
            if let photo = photo {
                imageView.image = photo.image
            }
        }
    }
    
}
