//
//  ViewController.swift
//  UnoiaGridImages
//
//  Created by MAC on 04/10/18.
//  Copyright © 2018 Ramneet. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UICollectionViewDelegate, UICollectionViewDataSource
{
    
    @IBOutlet weak var collectionView: UICollectionView!
   // @IBOutlet weak var logoImg: UIImageView!
    
    // variables
    var photos = PhotoModel.getPhotos()
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return UIStatusBarStyle.lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if UIApplication.shared.keyWindow?.traitCollection.forceTouchCapability == UIForceTouchCapability.available
        {
            registerForPreviewing(with: self, sourceView: view)

        }
        collectionView.backgroundColor = UIColor.clear
        collectionView.contentInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        
        // Set the PinterestLayout delegate
        if let layout = collectionView?.collectionViewLayout as? PinterestLayout {
            layout.delegate = self
        }
    }
    
}

extension ViewController: UICollectionViewDelegateFlowLayout  {
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
     func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlexiblePhotoCell", for: indexPath)
        
            if let imageCell = cell as? FlexiblePhotoCell {
            imageCell.photo =  photos[indexPath.item]
            }
        
        return cell
    }
    
}

//MARK: - PINTEREST LAYOUT DELEGATE
extension ViewController : PinterestLayoutDelegate {
    
    
    // Returns the photo height
    func collectionView(_ collectionView: UICollectionView, heightForPhotoAtIndexPath indexPath:IndexPath) -> CGFloat {
        
           if UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad {
             return photos[indexPath.item].image.size.height
           }
             return photos[indexPath.item].image.size.height*0.5
    }
    
}


extension ViewController: UIViewControllerPreviewingDelegate{

    func previewingContext(_ previewingContext: UIViewControllerPreviewing, viewControllerForLocation location: CGPoint) -> UIViewController? {
        
        let convertedLocation = view.convert(location, to: collectionView)
        
        if let indexPath = collectionView.indexPathForItem(at: convertedLocation)  {
            let cell = collectionView.cellForItem(at: indexPath) as! FlexiblePhotoCell
            
        if collectionView.bounds.contains(convertedLocation)
        {
            let popVC = storyboard?.instantiateViewController(withIdentifier: "PopViewController") as! PopViewController
            popVC.img.image = cell.photo?.image
            popVC.preferredContentSize = CGSize(width: 0.0, height: 600)
            return popVC
           }
        }
         return nil
    }

    
    func previewingContext(_ previewingContext: UIViewControllerPreviewing, commit viewControllerToCommit: UIViewController) {
       // if let ViewController = viewControllerToCommit as? PopViewController{
          //  ViewController.back.isHidden = false
       // }
        show(viewControllerToCommit, sender: self)
    }


}


