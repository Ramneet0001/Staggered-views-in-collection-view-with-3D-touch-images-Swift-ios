//
//  PhotoModel.swift
//  UnoiaGridImages
//
//  Created by MAC on 04/10/18.
//  Copyright © 2018 Ramneet. All rights reserved.
//

import UIKit

struct PhotoModel {
    
        var image: UIImage
    
        init(image: UIImage) {
            self.image = image
        }
        
        static func getPhotos() -> [PhotoModel] {
            var photos = [PhotoModel]()
            
            let arrayOfImages = ["https://picsum.photos/320/420?image=0",
                                 "https://placeimg.com/420/320/tech/grayscale",
                                 "https://placeimg.com/640/480/tech",
                                 "https://placeimg.com/200/400/tech/sepia",
                                 "https://placeimg.com/400/500/people/sepia",
                                 "https://placeimg.com/300/400/nature/sepia",
                                 "https://placeimg.com/200/200/arch/sepia",
                                 "https://placeimg.com/400/500/animals/sepia",
                                 "https://placekitten.com/420/320?image=2",
                                 "https://picsum.photos/200/300/?image=57",
                                 "https://picsum.photos/320/420?image=23"]
            
            // Here we can use servicess for more details from server
            
            for singleImg in arrayOfImages {
                
            let url = URL(string: singleImg)
            let data = try? Data(contentsOf: url!)
            
            if let imageData = data {
                let image = UIImage(data: imageData)
                let singleImg = PhotoModel.init(image: image!)
                photos.append(singleImg)
               }
            }
                    return photos
            }
    
        
}
